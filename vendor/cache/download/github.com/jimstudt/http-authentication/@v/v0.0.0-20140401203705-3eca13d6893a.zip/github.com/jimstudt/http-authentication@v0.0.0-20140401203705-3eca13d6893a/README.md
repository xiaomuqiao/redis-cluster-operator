http-authentication
===================

Go implementation of RFC 2617 HTTP Authentication: Basic and Digest Access Authentication

You will want to include one or both of the packages depending on your requirements.

~~~~ go
import "github/jimstudt/http-authentication/basic"
import "github/jimstudt/http-authentication/digest"
~~~~

The packages are documented in their own directories.