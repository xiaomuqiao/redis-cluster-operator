// +build js

package big

import "testing"

func TestBytes(t *testing.T) {
	t.Skip("broken")
}

func TestModSqrt(t *testing.T) {
	t.Skip("slow")
}
