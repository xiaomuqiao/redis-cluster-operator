// +build js

package fmt_test

const intCount = 100
