# Xorm Examples

Notice: all the examples will ask you install extra package `github.com/mattn/go-sqlite3`, since it depends on cgo. You have to compile it after you install a c++ compile. Please see [github.com/mattn/go-sqlite3](https://github.com/mattn/go-sqlite3).

And then, you can run the examples via `go run xxx.go`. Every go file is a standalone example.
