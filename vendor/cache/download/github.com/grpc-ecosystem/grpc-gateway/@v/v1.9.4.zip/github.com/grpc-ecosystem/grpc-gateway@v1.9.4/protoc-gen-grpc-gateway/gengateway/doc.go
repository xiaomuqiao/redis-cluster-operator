// Package gengateway provides a code generator for grpc gateway files.
package gengateway
