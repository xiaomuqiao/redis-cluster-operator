[![Build Status](https://travis-ci.org/heketi/utils.svg?branch=master)](https://travis-ci.org/heketi/utils)
[![GoDoc](https://godoc.org/github.com/heketi/utils?status.png)](https://godoc.org/github.com/heketi/utils)

# Heketi Utility Functions

Generic Go utility functions

# Licensing
Heketi is licensed under the Apache License, Version 2.0.  See [LICENSE](https://github.com/heketi/heketi/blob/master/LICENSE) for the full license text.
