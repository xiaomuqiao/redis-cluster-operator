// Generic RESTful application functions
package rest
