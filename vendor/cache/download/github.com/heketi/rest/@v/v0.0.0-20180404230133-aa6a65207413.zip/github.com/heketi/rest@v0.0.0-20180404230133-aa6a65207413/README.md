[![Build Status](https://travis-ci.org/heketi/rest.svg?branch=master)](https://travis-ci.org/heketi/rest)
[![GoDoc](https://godoc.org/github.com/heketi/rest?status.png)](https://godoc.org/github.com/heketi/rest)
# Heketi RESTful Functions

Generic Go RESTful funcitions

# Licensing
Heketi is licensed under the Apache License, Version 2.0.  See [LICENSE](https://github.com/heketi/heketi/blob/master/LICENSE) for the full license text.
