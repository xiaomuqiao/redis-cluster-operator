# -*- coding: utf-8 -*-
# flake8: noqa

__title__ = 'heketi'
__version__ = '1.0.2'
__author__ = 'Heketi authors'
__license__ = 'Apache License (2.0) or LGPLv3+'
__copyright__ = 'Copyright 2016 Heketi authors'


from .heketi import HeketiClient, TAGS_SET, TAGS_UPDATE, TAGS_DELETE
