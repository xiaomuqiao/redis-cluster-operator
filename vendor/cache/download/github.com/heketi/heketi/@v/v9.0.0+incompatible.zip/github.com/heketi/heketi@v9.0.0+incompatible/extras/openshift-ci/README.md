
# OpenShift CI Integration

This directory contains files used to aid in testing Heketi
as part of the openshift ci pipeline.

For more information about openshift-ci see:
* https://github.com/openshift/release
* https://github.com/openshift/ci-operator
