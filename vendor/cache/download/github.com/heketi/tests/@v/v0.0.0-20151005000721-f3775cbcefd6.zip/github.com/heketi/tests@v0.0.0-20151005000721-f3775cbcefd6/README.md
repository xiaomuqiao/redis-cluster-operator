[![Build Status](https://travis-ci.org/heketi/tests.svg?branch=master)](https://travis-ci.org/heketi/tests)
[![GoDoc](https://godoc.org/github.com/heketi/tests?status.png)](https://godoc.org/github.com/heketi/tests)
# Heketi Test Functions

Generic Go test funcitions

# Licensing
Heketi is licensed under the Apache License, Version 2.0.  See [LICENSE](https://github.com/heketi/heketi/blob/master/LICENSE) for the full license text.
