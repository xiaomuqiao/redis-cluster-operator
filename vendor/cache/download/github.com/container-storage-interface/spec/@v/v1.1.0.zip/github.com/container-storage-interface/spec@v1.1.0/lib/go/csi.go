// Package csi is the Container Storage Interface (CSI) specification
// repository. This package contains no functional code, and this file
// exists only to make it possible to import this repository with a Go
// dependency manager such as Dep (https://github.com/golang/dep).
package csi
