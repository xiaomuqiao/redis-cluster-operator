### Which version of the SDK was used?

### Which platform are you using? (ex: Windows, Linux, Debian)

### What problem was encountered?

### How can we reproduce the problem in the simplest way?

### Have you found a mitigation/solution?
