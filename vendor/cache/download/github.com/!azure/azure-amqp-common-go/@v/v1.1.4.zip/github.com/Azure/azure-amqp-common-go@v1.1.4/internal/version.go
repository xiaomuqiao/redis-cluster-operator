package common

const (
	// Version is the semantic version of the library
	Version = "1.1.4"
)
