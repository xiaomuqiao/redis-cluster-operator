### Fix or Enhancement?


- [ ] All tests passed
- [ ] Add changes to `changelog.md`

### Environment
- OS: Write here
- Go version: Write here