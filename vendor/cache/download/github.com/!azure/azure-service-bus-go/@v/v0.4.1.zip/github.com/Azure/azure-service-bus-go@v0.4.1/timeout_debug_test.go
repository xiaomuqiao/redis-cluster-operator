// +build debug

package servicebus

import "time"

const defaultTimeout = 200 * 24 * time.Hour
