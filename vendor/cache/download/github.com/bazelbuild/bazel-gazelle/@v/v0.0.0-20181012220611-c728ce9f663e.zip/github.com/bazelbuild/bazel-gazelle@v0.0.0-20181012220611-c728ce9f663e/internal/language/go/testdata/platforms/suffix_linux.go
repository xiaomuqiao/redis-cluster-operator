package platforms

import (
	_ "example.com/repo/platforms/generic"
	_ "example.com/repo/platforms/linux"
)
