package fixtures

type SomeNum uint64
type SomeString string
type SomeFunc func(SomeNum) bool
