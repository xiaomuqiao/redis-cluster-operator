lldb
====

Package lldb implements a low level database engine.

Installation: $ go get github.com/cznic/lldb

Documentation: [godoc.org/github.com/cznic/lldb](http://godoc.org/github.com/cznic/lldb)
