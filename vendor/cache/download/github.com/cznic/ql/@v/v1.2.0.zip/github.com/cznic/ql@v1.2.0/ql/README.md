ql
==

Command ql is a utility to explore a database, prototype a schema or test drive a query, etc.

Installation

    $ go get github.com/cznic/ql/ql

Documentation: [godoc.org/github.com/cznic/ql/ql](http://godoc.org/github.com/cznic/ql/ql)
