package safe

const Version = "v1.0.1"
