# github.com/gobuffalo/packr/v2 Stands on the Shoulders of Giants

github.com/gobuffalo/packr/v2 does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/gobuffalo/logger](https://godoc.org/github.com/gobuffalo/logger)

* [github.com/gobuffalo/packd](https://godoc.org/github.com/gobuffalo/packd)

* [github.com/karrick/godirwalk](https://godoc.org/github.com/karrick/godirwalk)

* [github.com/rogpeppe/go-internal](https://godoc.org/github.com/rogpeppe/go-internal)

* [github.com/sirupsen/logrus](https://godoc.org/github.com/sirupsen/logrus)

* [github.com/spf13/cobra](https://godoc.org/github.com/spf13/cobra)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)

* [golang.org/x/sync](https://godoc.org/golang.org/x/sync)

* [golang.org/x/tools](https://godoc.org/golang.org/x/tools)
