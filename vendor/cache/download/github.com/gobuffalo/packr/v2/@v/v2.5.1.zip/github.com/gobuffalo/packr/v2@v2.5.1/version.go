package packr

// Version of Packr
const Version = "v2.5.1"
