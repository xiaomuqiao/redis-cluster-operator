// Package main is the command line tool for Genny.
package main
