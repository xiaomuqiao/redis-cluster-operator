package multipletypes

type MyType1 struct{}

type MyOtherType struct{}
