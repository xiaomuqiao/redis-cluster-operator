## operator-sdk olm-catalog

Invokes a olm-catalog command

### Synopsis

The operator-sdk olm-catalog command invokes a command to perform
Catalog related actions.

### Options

```
  -h, --help   help for olm-catalog
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease
* [operator-sdk olm-catalog gen-csv](operator-sdk_olm-catalog_gen-csv.md)	 - Generates a Cluster Service Version yaml file for the operator

