## operator-sdk completion bash

Generate bash completions

### Synopsis

Generate bash completions

```
operator-sdk completion bash [flags]
```

### Options

```
  -h, --help   help for bash
```

### SEE ALSO

* [operator-sdk completion](operator-sdk_completion.md)	 - Generators for shell completions

