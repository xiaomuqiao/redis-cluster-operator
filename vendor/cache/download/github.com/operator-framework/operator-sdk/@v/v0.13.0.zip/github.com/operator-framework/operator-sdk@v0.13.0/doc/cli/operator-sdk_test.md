## operator-sdk test

Tests the operator

### Synopsis

The test command has subcommands that can test the operator.


### Options

```
  -h, --help   help for test
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease
* [operator-sdk test local](operator-sdk_test_local.md)	 - Run End-To-End tests locally

