## operator-sdk alpha olm status

Get the status of the Operator Lifecycle Manager installation in your cluster

### Synopsis

Get the status of the Operator Lifecycle Manager installation in your cluster

```
operator-sdk alpha olm status [flags]
```

### Options

```
  -h, --help               help for status
      --timeout duration   time to wait for the command to complete before failing (default 2m0s)
```

### SEE ALSO

* [operator-sdk alpha olm](operator-sdk_alpha_olm.md)	 - Manage the Operator Lifecycle Manager installation in your cluster

