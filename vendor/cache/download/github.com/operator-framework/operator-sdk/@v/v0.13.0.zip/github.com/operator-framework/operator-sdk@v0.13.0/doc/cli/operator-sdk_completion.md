## operator-sdk completion

Generators for shell completions

### Synopsis

Generators for shell completions

### Options

```
  -h, --help   help for completion
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease
* [operator-sdk completion bash](operator-sdk_completion_bash.md)	 - Generate bash completions
* [operator-sdk completion zsh](operator-sdk_completion_zsh.md)	 - Generate zsh completions

