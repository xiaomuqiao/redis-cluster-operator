# PullJson

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Blob** | **string** | Package blob: a tar.gz in b64-encoded | [optional] 
**Package** | **string** | Package name | [optional] 
**Release** | **string** | Package version | [optional] 
**Filename** | **string** | suggested filename | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


