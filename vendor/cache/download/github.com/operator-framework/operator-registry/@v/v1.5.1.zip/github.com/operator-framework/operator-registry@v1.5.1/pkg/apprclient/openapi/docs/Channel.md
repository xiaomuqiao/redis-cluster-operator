# Channel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Channel name | [optional] 
**Current** | **string** | Current/latest release in the channel. The channel returns this release by default | [optional] 
**Releases** | **[]string** | All availables releases in the channel | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


