package main

import (
	"testing"
)

// Test started when the test binary is started. Only calls main.
func TestALMMain(t *testing.T) {
	main()
}
