// Package crypto contains implementations of crypto.Signer.
package crypto
