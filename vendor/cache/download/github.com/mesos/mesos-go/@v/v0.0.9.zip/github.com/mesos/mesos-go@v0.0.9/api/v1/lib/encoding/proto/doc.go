// Package proto implements protobuf utilities such as functional options to
// construct complex structs and encoders and decoders composable with
// io.ReadWriters.
package proto
