package main

// Dummy main so that the example builds.
func main() {}
