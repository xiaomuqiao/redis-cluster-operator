xg-c-1.ok.po has a bad header, msgfmt can't compile it.
