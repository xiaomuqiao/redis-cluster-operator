# readahead

*This is not an official Google product*

readahead is a package that provides readers that enable concurrent
reads from seekable or compressed files. It's useful when reading from
a network file system (like Google Cloud Storage).

To install: `go get github.com/google/readahead`

For information on use, see the
[godoc](https://godoc.org/github.com/google/readahead).
