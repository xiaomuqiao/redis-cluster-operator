40MB test images created with different tools.
