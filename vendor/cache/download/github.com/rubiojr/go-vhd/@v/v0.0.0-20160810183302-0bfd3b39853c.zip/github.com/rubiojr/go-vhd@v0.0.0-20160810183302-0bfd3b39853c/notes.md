http://winntfs.com/2012/07/28/aligned-io-and-large-sector-disks-vhd-vhdx-and-vs-2012-install-4/
http://social.technet.microsoft.com/wiki/contents/articles/1548.some-observations-on-dynamic-vhd-performance.aspx
http://winntfs.com/2012/01/21/tips-for-copying-large-vhd-files/
http://www.virtualbox.org/svn/vbox/trunk/src/VBox/Storage/VHD.cpp
https://technet.microsoft.com/en-us/library/hh831459.aspx
