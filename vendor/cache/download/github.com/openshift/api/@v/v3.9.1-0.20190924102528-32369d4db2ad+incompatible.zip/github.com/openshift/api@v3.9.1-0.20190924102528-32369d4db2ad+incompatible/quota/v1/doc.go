// +k8s:deepcopy-gen=package,register
// +k8s:conversion-gen=github.com/openshift/origin/pkg/quota/apis/quota
// +k8s:defaulter-gen=TypeMeta
// +k8s:openapi-gen=true

// +groupName=quota.openshift.io
// Package v1 is the v1 version of the API.
package v1
