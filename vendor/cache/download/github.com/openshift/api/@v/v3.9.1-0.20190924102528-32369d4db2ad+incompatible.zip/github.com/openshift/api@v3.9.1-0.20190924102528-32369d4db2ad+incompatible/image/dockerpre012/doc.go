// +k8s:deepcopy-gen=package,register

// Package dockerpre012 is the dockerpre012 version of the API.
package dockerpre012
