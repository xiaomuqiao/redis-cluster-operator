juju/testing
============

This package provides additional base test suites to be used with
gocheck.


