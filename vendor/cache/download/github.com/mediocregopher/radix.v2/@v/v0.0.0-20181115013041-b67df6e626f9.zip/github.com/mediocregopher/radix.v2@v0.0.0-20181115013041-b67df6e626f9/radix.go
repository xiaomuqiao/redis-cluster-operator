// Package radix is a simple redis driver. This top-level package is a wrapper
// for its sub-packages and doesn't actually contain any code. You likely want
// to look at the redis sub-package for a straightforward redis client
package radix
