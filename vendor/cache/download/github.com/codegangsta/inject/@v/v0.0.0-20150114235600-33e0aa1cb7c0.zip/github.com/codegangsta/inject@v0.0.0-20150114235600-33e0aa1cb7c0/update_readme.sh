#!/bin/bash
go get github.com/robertkrimen/godocdown/godocdown
godocdown > README.md
