package main

import "github.com/coredns/corefile-migration/corefile-tool/cmd"

func main() {
	cmd.Execute()
}
