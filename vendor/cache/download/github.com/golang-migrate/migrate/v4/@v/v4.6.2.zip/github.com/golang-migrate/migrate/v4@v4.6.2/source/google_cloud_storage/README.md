# google_cloud_storage

`gcs://<bucket>/<prefix>`
