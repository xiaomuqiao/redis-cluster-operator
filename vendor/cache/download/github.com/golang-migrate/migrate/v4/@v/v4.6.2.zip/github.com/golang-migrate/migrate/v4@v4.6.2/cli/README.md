# Deprecated

Use [cmd/migrate](../cmd/migrate) instead
