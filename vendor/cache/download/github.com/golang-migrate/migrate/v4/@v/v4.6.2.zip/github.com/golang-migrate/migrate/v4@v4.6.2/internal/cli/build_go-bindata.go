// +build go_bindata

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/source/go_bindata"
)
