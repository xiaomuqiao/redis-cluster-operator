#!/bin/bash

exec /bin/cat
