[![Build Status](https://travis-ci.org/lpabon/godbc.svg?branch=master)](https://travis-ci.org/lpabon/godbc)

# godbc

Design by contract for Go

# Installation

To install godbc, use `go get`:

    go get github.com/lpabon/godbc

Import the `godbc` package into your code using this template:

    import (
      "github.com/lpabon/godbc"
    )

# Documentation

Documentation is available at https://godoc.org/github.com/lpabon/godbc
