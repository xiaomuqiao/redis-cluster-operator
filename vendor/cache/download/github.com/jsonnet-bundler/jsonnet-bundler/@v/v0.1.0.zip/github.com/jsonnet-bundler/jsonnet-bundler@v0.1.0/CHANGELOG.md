## 0.1.0 / 2019-04-23

This is the first release for jsonnet-bundler.
