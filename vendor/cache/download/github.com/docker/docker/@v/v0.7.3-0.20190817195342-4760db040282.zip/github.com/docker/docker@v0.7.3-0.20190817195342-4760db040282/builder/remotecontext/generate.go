package remotecontext // import "github.com/docker/docker/builder/remotecontext"

//go:generate protoc --gogoslick_out=. tarsum.proto
