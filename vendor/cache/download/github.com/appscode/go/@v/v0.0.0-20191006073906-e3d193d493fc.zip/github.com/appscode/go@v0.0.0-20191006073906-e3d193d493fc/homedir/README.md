Forked from https://github.com/kubernetes/client-go/tree/73165849782e703c1e59312e12ca86048374aa74/util/homedir
