/*
Package httpclient provides a simple Golang Client for JSON Http Microservices

Acknowledgement:
 - [DigitalOcean Go client](https://github.com/digitalocean/godo/blob/master/godo.go)
 - [OVH Go client](https://github.com/ovh/go-ovh/blob/master/ovh/ovh.go)
*/
package httpclient
