Forked from https://github.com/kubernetes/apimachinery/blob/20bbfef868144faf29af69ddb2f01646ead5c1a1/pkg/util/sets/byte.go#L19
