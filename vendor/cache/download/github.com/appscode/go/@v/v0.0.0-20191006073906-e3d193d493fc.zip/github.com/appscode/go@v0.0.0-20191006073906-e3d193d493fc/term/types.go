package term

import _env "github.com/appscode/go/env"

var Interactive = true

var Env = _env.FromHost()
