// Package types provides a collection of Golang types with JSON marshaling support
package types
