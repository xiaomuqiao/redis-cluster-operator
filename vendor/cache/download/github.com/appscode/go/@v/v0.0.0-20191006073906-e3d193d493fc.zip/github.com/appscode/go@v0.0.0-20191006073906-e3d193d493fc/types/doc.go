/*
GOlang value &lt;--> pointer

##Acknowledgements
This repo was started as a fork of https://github.com/aws/aws-sdk-go/blob/master/aws/convert_types.go
*/
package types
