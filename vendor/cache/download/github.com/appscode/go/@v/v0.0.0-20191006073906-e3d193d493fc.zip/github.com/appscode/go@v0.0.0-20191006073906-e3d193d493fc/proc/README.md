Forked from https://github.com/openshift/library-go/tree/f7ae9d85accb03d7a7002615c67848838b2c381c/pkg/proc

xref: https://github.com/openshift/library-go/pull/127/files

Background:
- [Docker and the PID 1 zombie reaping problem](https://blog.phusion.nl/2015/01/20/docker-and-the-pid-1-zombie-reaping-problem/)
- [WAIT(2) ](http://man7.org/linux/man-pages/man2/wait.2.html)

