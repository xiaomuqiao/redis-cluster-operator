# k8s-cloud-provider

This repository contains support files for implementing the Kubernetes cloud
provider for the Google Cloud Platform. The code in this repository are the
Google Cloud specific portions of the cloud provider logic.

## Building

Run `make`.

## Update GCE Go Client

For every update on the GCE API Go client, please remember to push a new tag.
