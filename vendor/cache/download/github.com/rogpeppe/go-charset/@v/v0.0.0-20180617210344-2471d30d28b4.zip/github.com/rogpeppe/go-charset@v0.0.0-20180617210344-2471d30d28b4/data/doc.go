// The data package embeds all the charset
// data files as Go data. It registers the data with the charset
// package as a side effect of its import. To use:
//
//	import _ "code.google.com/p/go-charset"
package data
