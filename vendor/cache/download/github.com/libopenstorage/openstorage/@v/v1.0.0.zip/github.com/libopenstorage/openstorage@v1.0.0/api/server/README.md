## package apiserver

Package apiserver defines the REST endpoints for volume drivers.

The endpoints defined by the docker volume plugins API is a subset of the exposed
REST endpoints.
