## Sample openstorage spec files

This directory contains a few examples of spec files in both JSON and YAML formats.  Refer to the [specs](https://github.com/libopenstorage/specs) to understand the format.
