package main

import (
	"fmt"
	_ "github.com/rancher/go-rancher/client"
)

func main() {
	fmt.Println("I have nothing to do...")
}
