//go:generate _generator/to_list descriptors.txt animals.txt
package moniker
