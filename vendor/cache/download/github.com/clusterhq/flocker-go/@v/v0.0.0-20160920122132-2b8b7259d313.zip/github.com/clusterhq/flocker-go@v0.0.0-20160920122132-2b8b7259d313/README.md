flocker-go
==========

[![circleci](https://circleci.com/gh/ClusterHQ/flocker-go.svg)](https://circleci.com/gh/ClusterHQ/flocker-go)

flocker-go implements the package `flocker` that will let you easily interact
with a Flocker Control Service.

What can it do?
---------------

You can check the package documentation here: https://godoc.org/github.com/ClusterHQ/flocker-go

TODO
----

- Define a proper interface `flockerClientable` with all the needed methods for
  wrapping the Flocker API.
