// +build integration

package runhcs

import (
	_ "github.com/Microsoft/hcsshim/test/functional/manifest"
)
