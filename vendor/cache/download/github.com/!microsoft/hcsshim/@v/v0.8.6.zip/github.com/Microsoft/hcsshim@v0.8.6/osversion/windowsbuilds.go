package osversion

const (

	// RS2 was a client-only release in case you're asking why it's not in the list.
	RS1 = 14393
	RS3 = 16299
	RS4 = 17134
	RS5 = 17763
)
