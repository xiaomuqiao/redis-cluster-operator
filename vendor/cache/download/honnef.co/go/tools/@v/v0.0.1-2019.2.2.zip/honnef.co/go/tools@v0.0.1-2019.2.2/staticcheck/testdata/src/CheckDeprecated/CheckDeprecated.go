package pkg

import _ "CheckDeprecatedassist" // want `Alas, it is deprecated\.`
