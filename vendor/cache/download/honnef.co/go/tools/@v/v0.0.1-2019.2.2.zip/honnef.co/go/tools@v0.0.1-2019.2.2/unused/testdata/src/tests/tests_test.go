package pkg

import "testing"

func TestFn(t *testing.T) {
	fn()
}
