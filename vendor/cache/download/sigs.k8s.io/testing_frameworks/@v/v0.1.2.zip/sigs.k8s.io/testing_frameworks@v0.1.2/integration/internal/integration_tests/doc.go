/*
Package integrarion_tests is holding the integration tests to run against the
framework.

This file's only purpose is to make godep happy.
*/
package integration_tests
