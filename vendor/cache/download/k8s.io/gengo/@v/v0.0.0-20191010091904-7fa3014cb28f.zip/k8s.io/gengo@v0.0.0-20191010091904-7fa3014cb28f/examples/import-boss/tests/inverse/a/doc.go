// a only imports public packages.
package a

import (
	_ "k8s.io/gengo/examples/import-boss/tests/inverse/lib/public"
)
