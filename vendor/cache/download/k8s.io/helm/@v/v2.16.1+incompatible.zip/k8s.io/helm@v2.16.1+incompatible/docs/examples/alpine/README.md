# Alpine: A simple Helm chart

Run a single pod of Alpine Linux.

The `templates/` directory contains a very simple pod resource with a
couple of parameters.

The `values.yaml` file contains the default values for the
`alpine-pod.yaml` template.

You can install this example using `helm install docs/examples/alpine`.
