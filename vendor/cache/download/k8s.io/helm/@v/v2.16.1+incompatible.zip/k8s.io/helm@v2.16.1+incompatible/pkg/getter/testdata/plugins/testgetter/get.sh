#!/bin/bash

echo ENVIRONMENT
env

echo ""
echo ARGUMENTS
echo $@
