## Subpop 

This chart is for testing the processing of enabled/disabled charts  
via conditions and tags.

Currently there are three levels:

````
parent
-1 tags: front-end, subchart1
--A tags: front-end, subchartA
--B tags: front-end, subchartB
-2 tags: back-end, subchart2
--B tags: back-end, subchartB
--C tags: back-end, subchartC
````

Tags and conditions are currently in requirements.yaml files.