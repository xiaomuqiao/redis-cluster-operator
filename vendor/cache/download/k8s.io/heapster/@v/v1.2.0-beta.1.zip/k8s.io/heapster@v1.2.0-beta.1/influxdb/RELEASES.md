# Release Notes for heapster influxdb container.

## 0.7 (06-27-2016)
- updated to v0.12.2-1

## 0.6 (12-10-2015)
- updated to v0.9.6

## 0.5 (9-18-2015)
- updated to v0.9.4

## 0.4 (9-17-2015)
- Updated to InfluxDB v0.8.9 to pave way for safely upgrading to influxDB v0.9.x

## 0.3 (1-19-2015)
- Updated Influxdb version number to 0.8.8, paving way for collectd support.
