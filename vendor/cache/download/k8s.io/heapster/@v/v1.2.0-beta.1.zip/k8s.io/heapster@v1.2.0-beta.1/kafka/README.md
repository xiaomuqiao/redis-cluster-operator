heapster_kafka
================

Monitoring for Kubernetes container metrics

this docker image runs both Zookeeper and Kafka in the same container. 
This means:

No dependency on an external Zookeeper host, or linking to another container
Zookeeper and Kafka are configured to work together out of the box

