A Docker image that is used to build vpa-related binaries.
