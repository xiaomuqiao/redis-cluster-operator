package issue29559

type AString = string

func TakesAString(s AString) {}
