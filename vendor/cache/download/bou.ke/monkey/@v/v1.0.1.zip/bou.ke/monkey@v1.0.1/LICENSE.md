Copyright Bouke van der Bijl

I do not give anyone permissions to use this tool for any purpose. Don't use it.
