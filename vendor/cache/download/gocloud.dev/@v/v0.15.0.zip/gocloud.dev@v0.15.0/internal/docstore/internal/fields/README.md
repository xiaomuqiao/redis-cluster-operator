This package is copied from cloud.google.com/go/internal/fields.
