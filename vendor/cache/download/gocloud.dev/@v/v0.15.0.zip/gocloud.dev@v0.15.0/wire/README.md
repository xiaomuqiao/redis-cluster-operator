# Wire has moved!

Wire has moved to its own repository: [github.com/google/wire](https://github.com/google/wire)

Read the [announcement][] for more details.

[announcement]: https://groups.google.com/d/msg/go-cloud/4HuWfjDAkOY/Y2tUQdB_BQAJ
