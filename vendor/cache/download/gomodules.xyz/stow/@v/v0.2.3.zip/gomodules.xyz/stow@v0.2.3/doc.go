// Package stow provides an abstraction on cloud storage capabilities.
package stow
