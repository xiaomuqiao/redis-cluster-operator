## sortorder [![GoDoc](https://godoc.org/vbom.ml/util/sortorder?status.svg)](https://godoc.org/vbom.ml/util/sortorder)

    import "vbom.ml/util/sortorder"

Sort orders and comparison functions.
