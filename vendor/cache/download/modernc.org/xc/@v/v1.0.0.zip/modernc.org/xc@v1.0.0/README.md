# xc
Package xc provides cross language compiler support/utility stuff.

Installation

    $ go get modernc.org/xc

Documentation: [godoc.org/modernc.org/xc](http://godoc.org/modernc.org/xc)
