---
name: Question
about: Ask at the Gonum discussion list https://groups.google.com/forum/#!forum/gonum-dev

---
<!--
For question about usage or similar, please ask at the Gonum discussion list
rather than filing an issue:

https://groups.google.com/forum/#!forum/gonum-dev
-->

# :no_entry_sign: INVALID :no_entry_sign:
