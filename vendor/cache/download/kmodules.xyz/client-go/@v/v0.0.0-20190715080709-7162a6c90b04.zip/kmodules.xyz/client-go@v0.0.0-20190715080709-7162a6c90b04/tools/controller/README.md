Forked from https://github.com/kubernetes/kubernetes/tree/0ed33881dc4355495f623c6f22e7dd0b7632b7c0/pkg/controller

xref: https://github.com/kubevault/project/issues/16
