package v1

import (
	jsoniter "github.com/json-iterator/go"
)

var json = jsoniter.ConfigFastest
