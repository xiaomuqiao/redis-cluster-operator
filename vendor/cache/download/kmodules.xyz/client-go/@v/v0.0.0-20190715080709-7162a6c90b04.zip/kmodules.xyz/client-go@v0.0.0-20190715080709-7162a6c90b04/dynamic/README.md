Forked from https://github.com/GoogleCloudPlatform/metacontroller
