// +k8s:deepcopy-gen=package
// +k8s:openapi-gen=true
package v1 // import "kmodules.xyz/objectstore-api/api/v1"
