[![Go Report Card](https://goreportcard.com/badge/kmodules/objectstore-api "Go Report Card")](https://goreportcard.com/report/kmodules/objectstore-api)
[![GoDoc](https://godoc.org/kmodules.xyz/objectstore-api?status.svg "GoDoc")](https://godoc.org/kmodules.xyz/objectstore-api)
[![Build Status](https://travis-ci.org/kmodules/objectstore-api.svg?branch=master)](https://travis-ci.org/kmodules/objectstore-api)

# objectstore-api
ObjectStore API for Kubernetes CRDs
