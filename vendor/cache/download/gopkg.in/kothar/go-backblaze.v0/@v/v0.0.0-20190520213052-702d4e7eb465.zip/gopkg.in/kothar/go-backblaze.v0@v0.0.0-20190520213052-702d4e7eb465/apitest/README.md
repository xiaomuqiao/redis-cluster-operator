## apitest

`apitest` will create a bucket, upload some test files, download, delete,
and otherwise verify that the API methods supported by go-backblaze all
function as expected.

Note that you use this program at your own risk. Don't use it with account
credentials with access to sensitive files.
