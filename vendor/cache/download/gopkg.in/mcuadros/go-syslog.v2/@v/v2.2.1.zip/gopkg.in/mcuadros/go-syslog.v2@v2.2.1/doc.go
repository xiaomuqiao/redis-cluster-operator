/*
Syslog server library for go, build easy your custom syslog server
over UDP, TCP or Unix sockets using RFC3164, RFC5424 and RFC6587
*/
package syslog // import "gopkg.in/mcuadros/go-syslog.v2"
